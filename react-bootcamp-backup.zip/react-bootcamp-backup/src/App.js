import Layout from "./layouts/layout";
import Test from "./test";

function App() {
  return (
      <>
        {/*<Test/>*/}
        <Layout/>
      </>
  );
}

export default App;
