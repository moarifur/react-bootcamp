import React, {Component} from 'react';

class Counter extends Component {
    render() {
        return (
            <>
                <h1>Hello</h1>
            </>
        );
    }
}

export default Counter;